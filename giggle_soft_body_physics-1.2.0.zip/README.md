# Giggle Soft Body Physics — 1.2.0

A Blender character-secondary-motion add-on using the bundled Wiggy XPBD Geometry Nodes group.

## Requirements

- Blender 5.2 or newer.
- The bundled `assets/Wiggy_0.1.blend` and `assets/JiggleV2.blend` files must remain in the `assets/` directory next to `__init__.py`.

## Install

1. In Blender, open **Edit → Preferences → Get Extensions** (or **Add-ons**, depending on the Blender build).
2. Use **Install from Disk** and select `giggle_soft_body_physics-1.2.0.zip`.
3. Enable **Giggle Soft Body Physics**.
4. In the 3D Viewport, open the **N-panel → Giggle** tab.

## First simulation

1. Select a character mesh and create a vertex group for the region to simulate.
2. Paint non-zero weights on the intended vertices. Blend the weights at the boundary rather than using a hard binary mask.
3. In **Create New Zone**, select that group and choose a preset. New zones use **Wiggy XPBD**.
4. Click **Add Jiggle Zone**. The add-on places the modifier after armature deformation and before later surface finishing modifiers where possible.
5. Start playback from the scene start frame to evaluate the simulation. If you change important solver settings, reset/restart the simulation from the beginning.

## Preset profiles

Version 1.2.0 introduces distinct motion-response profiles rather than relying mainly on a softness change. The profiles cover restrained/short travel, controlled elasticity, athletic shape retention, compression, balanced motion, soft tissue, heavy lag, viscous/slosh response, high rebound, springy motion, structured/fabric response, weighted hair swing, ribbon flow, compact damping, water-balloon motion, loaded accessories, and lightweight motion.

The profiles are art-directed starting points, not laboratory-calibrated material data. The Mass / Inertia control is a relative solver value, not a guaranteed real-world kilogram measurement. Character scale, mesh density, vertex weights, armature motion, collision geometry, and frame rate all affect the final result.

## Compatibility notes

- **Wiggy XPBD** is the supported engine for creating new zones and applying the reworked preset library.
- Existing **Jiggle V2** modifiers are retained for legacy projects and keep their basic dynamics controls. The add-on no longer offers creation of new Jiggle V2 zones because its input layout is incompatible with Wiggy preset and vertex-group workflows.
- Presets and support levels are available on Wiggy zones only.

## Troubleshooting

- A zone with an empty vertex group will remain inactive until weights are painted.
- If the simulation looks frozen or inconsistent after changing settings, return to the scene start frame and play forward.
- If the mesh explodes or clips, reduce the zone's max distance and sway, inspect boundary weights, and verify collider scale/placement.
- Use a lower-resolution simulation mesh where possible and add subdivision after the simulation modifier.
